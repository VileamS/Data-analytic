# An Analysis of Kickstarter Campaigns
Hi Louise My name is Vileam Siv.
I have all the data and analysis for your Kickstarter preparations.
In this Exel you will able to understand failed and successfull campaingns in each country, and that will help you start your preparation.
There are different sheets in the excel.
First, we have the outcomes based on launch date. There is a pivot chart in the sheet. you can filter through to understand specificly about each of those outcomes.
I also have the chart as a picture and filter for Theater. 
Second, We have the subcategory statistics. In this pivot table, you will be able to filter all of those campaingns by parental category and Subcategory.
git 